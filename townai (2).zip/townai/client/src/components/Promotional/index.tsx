
export { default as PromotionalBanner } from './PromotionalBanner';
