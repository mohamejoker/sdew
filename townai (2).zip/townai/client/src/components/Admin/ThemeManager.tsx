
import React from 'react';
import ThemeManagerComponent from './ThemeManager/index';

// Re-export the refactored component for backward compatibility
export default ThemeManagerComponent;
