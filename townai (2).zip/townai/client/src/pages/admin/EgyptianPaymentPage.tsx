
import React from 'react';
import EgyptianPaymentManager from '@/components/Admin/EgyptianPaymentManager';

const EgyptianPaymentPage = () => <EgyptianPaymentManager />;

export default EgyptianPaymentPage;
