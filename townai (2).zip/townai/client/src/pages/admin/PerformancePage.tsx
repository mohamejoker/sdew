
import React from 'react';
import PerformancePanel from '@/components/Admin/PerformancePanel';

const PerformancePage = () => {
  return <PerformancePanel />;
};

export default PerformancePage;
