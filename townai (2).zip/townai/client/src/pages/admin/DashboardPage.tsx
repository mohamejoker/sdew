
import React from 'react';
import AdvancedAdminDashboard from '@/components/Dashboard/AdvancedAdminDashboard';

const DashboardPage = () => {
  return <AdvancedAdminDashboard />;
};

export default DashboardPage;
