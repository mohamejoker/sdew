
import React from 'react';
import UISettingsPanel from '@/components/Admin/UISettingsPanel';

const UIPage = () => {
  return <UISettingsPanel />;
};

export default UIPage;
