
import React from 'react';
import AdminProvidersManager from '@/components/Admin/AdminProvidersManager';

const ProvidersPage = () => <AdminProvidersManager />;

export default ProvidersPage;
